<?php header("Content-Type: text/html; charset=UTF-8"); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript">$(document).ready(function() {

	$('form').submit(function(event) {

		event.preventDefault();

		$.ajax({
			type: $(this).attr('method'),
			url: $(this).attr('action'),
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData: false,
			success: function(result) {
				alert(result)
			},
		});
	
	});

});</script>
</head>
<body>
	<h1>Відправка пошти</h1>
	<form action="mail.php" method="post" enctype="multipart/form-data">
		<p>Кому: <input type="email" placeholder="Кому" value="people@gmail.com"name="to"></p>
<p>Від Кого ім`я: <input type="text" placeholder="Від Кого - імя" value="Людина" name="fromname"></p>
<p>Від Кого email: <input type="email" placeholder="Від Кого - email" value="stiv.jobs@apple.com" name="from"></p>
<p>Тема: <input type="text" placeholder="Тема" value="Привіт я Стів" name="sub"></p>
		<p>Тип повідомлення: <td>
                <select name="tip" id="tip" size=2>
                <option value=2 selected>text</option>
                <option value=1>html</option>
                </select>
            </td></p>
<p>

<textarea cols="50" rows="17" name="mess">
</textarea>
<input type="file" name="file">
</p>
		<p><input type="submit" value="Відправити"></p>
	</form>
</body>
</html>

