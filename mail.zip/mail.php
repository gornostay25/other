<?php
$conf['smtp_username'] = 'mail@74wvduawro2c20x6.ml';  //Смените на адрес своего почтового ящика.
$conf['smtp_port'] = '465'; // Порт работы.
$conf['smtp_host'] =  'ssl://smtp.yandex.ru';  //сервер для отправки почты
$conf['smtp_password'] = '123qazwsx';  //Измените пароль
$conf['smtp_debug'] = true;  //Если Вы хотите видеть сообщения ошибок, укажите true вместо false 
$conf['tip'] = ($_POST['tip'] == 2) ? 'text/plain' : 'text/html';
$conf['smtp_charset'] = 'utf-8';	//кодировка сообщений. (windows-1251 или utf-8, итд)      
$tip = ($_POST['tip'] == 2) ? 'text/plain' : 'text/html';              
$chars = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
 $pass = "";
 $pass .= $chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)].$chars[rand(0, strlen($chars)-1)];
if ( !empty( $_FILES['file']['tmp_name'] ) and $_FILES['file']['error'] == 0 ) {
    $filepath = $_FILES['file']['tmp_name'];
    $filename = $_FILES['file']['name'];
$tip = 'multipart/mixed';
  } else {
    $filepath = '';
    $filename = '';
  }


function add_attachments($filepath, $filename) {
global $conf;
global $pass;
		
   
 $file = '';
  if ( !empty( $filepath ) ) {
    $fp = fopen($filepath, "r"); 
    if ( $fp ) { 
      $content = fread($fp, filesize($filepath)); 
      fclose($fp);
$file = chunk_split(base64_encode($content))."\r\n"; 
    }     
            $bound .= "\r\n".'------------'.$pass.''."\r\n";
            $bound .= "Content-Type: application/octet-stream;name= ".$filename."\r\n";
            $bound .= "Content-transfer-encoding: base64\r\n";
            $bound .= "Content-Disposition: attachment; filename=".$filename."\r\n\r\n".$file.'';
//$bound  = $bound."\r\n".'------------'.$pass.'--'."\r\n";
        }
            
			return $bound;
    }


$headers = headers($_POST['to'], $_POST['from'], $_POST['fromname'], $_POST['sub']);
$to = $_POST['to'];

function headers($to, $from, $fromname, $sub) {
global $conf;
global $tip;
global $pass;
    	$headers  = "Date: ".date("D, d M Y H:i:s",(time()-(3*60*60)))." UT\r\n";
    	if (!$fromname) { $header .="From: ".$from."\r\n"; } else {
		$headers .= "From: \"=?".$conf['smtp_charset']."?B?".base64_encode($fromname)."=?=\" <".$from.">\r\n";
}
    	$headers .= "X-Mailer: The Bat! (v3.99.3) Professional\r\n";
    	$headers .= "Reply-To: ".$from."\r\n";
  $headers .= "X-Priority: 3\r\n";
        $headers .="Message-ID: <172562218.".date("YmjHis")."@74wvduawro2c20x6.ml>\r\n";
    	$headers .= "To: ".$to."\r\n";
        $headers .= 'Subject: =?'.$conf['smtp_charset'].'?B?'.base64_encode($sub)."=?=\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        if($tip=='multipart/mixed'){
            $headers.="Content-Type: multipart/mixed; boundary=\"----------".$pass."\"\r\n\r\n";

      
        }
     
        
        
        return $headers;
	}
  $mes = $_POST['mess'];  

  function letter_construct() {
global $conf;
global $tip;
global $mes;
global $pass;
global $headers;
global  $filepath; 
global  $filename; 
$headers=$headers;

        if($tip=='multipart/mixed'){
            $mes="------------".$pass."
            Content-Transfer-Encoding: 8bit
            Content-Type: ".$conf['tip']."; charset=\"".$conf['smtp_charset']."\"\r\n\r\n".$mes;
            $attachments = add_attachments($filepath, $filename);
            $letter=$headers.$mes."\r\n".$attachments."\r\n\r\n";  
        }else {
$mes="Content-Transfer-Encoding: 8bit"."\r\n"."Content-Type: ".$conf['tip']."; charset=\"".$conf['smtp_charset']."\"\r\n\r\n".$mes;

            $letter=$headers.$mes."\r\n";
}
        return $letter;
	} 
$send = letter_construct();

function smail($snd, $mail_to) {
	global $conf;
	$SEND = $snd;

	 if( !$socket = fsockopen($conf['smtp_host'], $conf['smtp_port'], $errno, $errstr, 30) ) {
		if ($conf['smtp_debug']) echo $errno."<br>".$errstr;
		return false;
	 }
 
	if (!server_parse($socket, "220", __LINE__)) return false;
 
	fputs($socket, "HELO " . $conf['smtp_host'] . "\r\n");
	if (!server_parse($socket, "250", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Не могу отправить HELO!</p>';
		fclose($socket);
		return false;
	}
	fputs($socket, "AUTH LOGIN\r\n");
	if (!server_parse($socket, "334", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Не могу найти ответ на запрос авторизаци.</p>';
		fclose($socket);
		return false;
	}
	fputs($socket, base64_encode($conf['smtp_username']) . "\r\n");
	if (!server_parse($socket, "334", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Логин авторизации не был принят сервером!</p>';
		fclose($socket);
		return false;
	}
	fputs($socket, base64_encode($conf['smtp_password']) . "\r\n");
	if (!server_parse($socket, "235", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Пароль не был принят сервером как верный! Ошибка авторизации!</p>';
		fclose($socket);
		return false;
	}
	fputs($socket, "MAIL FROM: <".$conf['smtp_username'].">\r\n");
	if (!server_parse($socket, "250", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Не могу отправить комманду MAIL FROM: </p>';
		fclose($socket);
		return false;
	}
	fputs($socket, "RCPT TO: <" . $mail_to . ">\r\n");
 
	if (!server_parse($socket, "250", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Не могу отправить комманду RCPT TO: </p>';
		fclose($socket);
		return false;
	}
	fputs($socket, "DATA\r\n");
 
	if (!server_parse($socket, "354", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Не могу отправить комманду DATA</p>';
		fclose($socket);
		return false;
	}
	fputs($socket, $SEND."\r\n.\r\n");
 
	if (!server_parse($socket, "250", __LINE__)) {
		if ($conf['smtp_debug']) echo '<p>Не смог отправить тело письма. Письмо не было отправленно!</p>';
		fclose($socket);
		return false;
	}
	fputs($socket, "QUIT\r\n");
	fclose($socket);
	return TRUE;
}
 
function server_parse($socket, $response, $line = __LINE__) {
	global $conf;
	while (@substr($server_response, 3, 1) != ' ') {
		if (!($server_response = fgets($socket, 256))) {
			if ($conf['smtp_debug']) echo "<p>Проблемы с отправкой почты!</p>$response<br>$line<br>";
 			return false;
 		}
	}
	if (!(substr($server_response, 0, 3) == $response)) {
		if ($conf['smtp_debug']) echo "<p>Проблемы с отправкой почты!</p>$response<br>$line<br>";
		return false;
	}
	return true;
}
if(smail($send, $to)) echo $send;
